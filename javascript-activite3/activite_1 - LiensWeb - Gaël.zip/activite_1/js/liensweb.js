/******************************Bonjour*****************************************/
/**************Attention au commentaire ligne 40 à 44 merci :)*****************/

var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    }, {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    }, {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

// Fonction pour le style d'un element (ici les liens en bleus - cf ligne 57  ) :
function styling(element) {
    element.style.color = "#428bca";
    element.style.fontSize = "1.3em";
    element.style.textDecoration = "none";
    element.style.fontWeight = "bold";
}

// Passe le tableau listeLiens en revue :
for (i = 0; i < listeLiens.length; i++) {
    // Crée les blocs lien contenant les 3 infos :
    var lienDivElt = document.createElement("div");
    lienDivElt.setAttribute("class", "lien"); // Attribut la classe 'lien' (cf .css)
    document.getElementById("contenu").appendChild(lienDivElt); // Chaque bloc se place dans le div 'contenu'

    // Crée les liens (en bleus) :
    var lienElt = document.createElement("a");
    lienElt.href = listeLiens[i].url;
    lienElt.textContent = listeLiens[i].titre
    lienDivElt.appendChild(lienElt); // Place le lien dans le bloc lien lienDivElt

    /* A present 2 techniques pour mettre l'url a côté du lien en bleu :
    1) Utiliser la balise span (car presente dans le .css !).
    2) Utiliser la methode insertAdjacentHTML() --> Bien plus ressemblant a l'exemple !
    Dans tous les cas les 2 techniques mettent l'info url a droite du lien.
    Decommenter lignes 44 à 46 & commenter la 51 pour voir le resultat avec la methode 1 : */

    //var urlElt = document.createElement("span");
    //urlElt.textContent = " " + listeLiens[i].url;
    //lienDivElt.appendChild(urlElt);

    lienElt.insertAdjacentHTML("afterend", " " + listeLiens[i].url); // Methode avec insert..

    var auteurElt = document.createElement("div");
    auteurElt.textContent = "Ajouté par " + listeLiens[i].auteur;
    lienDivElt.appendChild(auteurElt);

    styling(lienElt);
}
